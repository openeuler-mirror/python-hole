Changes
=======


20211123 - 0.7.0
----------------

- Allow later ``async_timeout``
- Remove loop (thanks @bdraco)

20211023 - 0.6.0
----------------

20211023 - 0.6.0
----------------

- Add version (thanks @Olen)
- Update Python releases


20200325 - 0.5.1
----------------

- Reduce verbosity (thanks @fermulator)

20190817 - 0.5.0
----------------

- Add '=' for api_token parameter (thanks @johnluetke)
- Add versions method (thanks @wfriesen)


20190115 - 0.4.0
-----------------

- Add enable/disable functions

201806014 - 0.3.0
-----------------

- Initial release
